#!/bin/bash

namespace="coordinator"
helm uninstall common -n "$namespace"
kubectl delete namespace "$namespace" --ignore-not-found

file=application/helmchart/lab_v2x/orin.yaml
filename=$(basename "$file")

namespace="${filename%.yaml}"
helm uninstall road -n "$namespace"

helm uninstall v2x -n "$namespace"

kubectl delete namespace "$namespace" --ignore-not-found

