# RTSP stream generator

This stream generator is used for emulating camera streams in a dynamic way. 

## Initial setting

Config stream info in `rtsp-source-config.yaml`.
Launch the RTSP server:
```bash
$ docker run --rm -it --network=host aler9/rtsp-simple-server
```

Launch ffmpeg stream maker:
```bash
$ python ffmpeg_stream_config.py
```

## Config in runtime

Launch ffmpeg dynamic config script, which controls the status of RTSP stream:
```bash
$ python ffmpeg_stream_dyn_input.py 
```

Then enter the desire stream status in the cmd line. E.g., "1,1,0". which means that the 1st two streams are turned on, and the 3rd one is off. 
