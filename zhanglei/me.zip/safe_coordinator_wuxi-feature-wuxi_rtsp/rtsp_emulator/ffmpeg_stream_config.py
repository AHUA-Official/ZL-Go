import subprocess
import yaml
import argparse
import socket

class StreamManager:
    def __init__(self, config_file):
        self.streams = {}
        self.load_config(config_file)

    def load_config(self, config_file):
        with open(config_file, 'r') as file:
            config = yaml.safe_load(file)
            for stream in config['streams']:
                name = stream['name']
                file_path = stream['file']
                url = stream['url']
                self.streams[name] = {
                    'file': file_path,
                    'url': url,
                    'process': None,
                    'running': False
                }

    def start_stream(self, name):
        if name in self.streams:
            stream = self.streams[name]
            if not stream['running']:
                command = [
                    'ffmpeg',
                    '-re',
                    '-stream_loop', '-1',
                    '-i', stream['file'],
                    '-an',
                    '-c', 'copy',
                    '-f', 'rtsp',
                    stream['url']
                ]
                stream['process'] = subprocess.Popen(command)
                stream['running'] = True
                print(f"Started streaming {name} to {stream['url']}")
            else:
                print(f"Stream {name} is already running.")
        else:
            print(f"Stream {name} not found in configuration.")

    def stop_stream(self, name):
        if name in self.streams:
            stream = self.streams[name]
            if stream['running']:
                stream['process'].terminate()
                stream['process'].wait()
                stream['running'] = False
                print(f"Stopped streaming {name}.")
            else:
                print(f"Stream {name} is not running.")
        else:
            print(f"Stream {name} not found in configuration.")

    def manage_streams(self, command):
        parts = command.strip().split()
        if len(parts) < 2:
            return "Invalid command. Please try again."

        action = parts[0].lower()
        name = parts[1]

        if action == 'start':
            self.start_stream(name)
            return f"Started stream {name}."
        elif action == 'stop':
            self.stop_stream(name)
            return f"Stopped stream {name}."
        else:
            return "Invalid command. Please try again."

    def run_server(self, host='localhost', port=12345):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.bind((host, port))
            server_socket.listen()
            print(f"Listening for commands on {host}:{port}")

            while True:
                conn, addr = server_socket.accept()
                with conn:
                    print(f"Connected by {addr}")
                    while True:
                        command = conn.recv(1024).decode()
                        if not command:
                            break
                        response = self.manage_streams(command)
                        conn.sendall(response.encode())

def main():
    parser = argparse.ArgumentParser(description='Manage video streams using FFmpeg.')
    parser.add_argument('--config', default='rtsp-source-config.yaml', help='Path to the configuration YAML file.')

    args = parser.parse_args()

    manager = StreamManager(args.config)

    # Start all streams initially
    stream_names = list(manager.streams.keys())
    for name in stream_names:
        manager.start_stream(name)

    # Start the command server
    manager.run_server()

if __name__ == "__main__":
    main()
