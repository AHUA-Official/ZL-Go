# Mosquitto

This Chart bootstraps a Eclipse-Mosquitto Deployment

## Configuration

See [values.yaml](https://github.com/t3n/helm-charts/blob/master/mosquitto/values.yaml) for required values and explanations
