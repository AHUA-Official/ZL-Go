from time import sleep,time
from jtop import jtop
import asyncio
import argparse
import schedule
import signal
import json
import logging
from prometheus_client import start_http_server
from prometheus_client.core import REGISTRY, GaugeMetricFamily
import paho.mqtt.client as mqtt

#logging.basicConfig(level=logging.WARNING)

# MQTT Client
mqtt_client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        logging.info("MQTT connected successfully.")
    else:
        logging.error(f"MQTT connection failed with code {rc}.")

mqtt_client.on_connect = on_connect

def publish_heartbeat(node_name, topic):
        timestamp = time()
        message = {"node_name": node_name, "timestamp": timestamp}
        mqtt_client.publish(topic, json.dumps(message))
        logging.info(f"{message}: MQTT message published.")

async def check_node(node_name, time_interval, topic):
    while True:
        publish_heartbeat(node_name, topic)
        await asyncio.sleep(time_interval)

class JtopObservable(object):

    def __init__(self, update_period=0.5):
        self.data = {}

        with jtop(interval=update_period) as jetson:
            self.jetson = jetson

    def read_stats(self):
        self.data = {
            "stats": self.jetson.stats,
            "board": self.jetson.board,
            "cpu": self.jetson.cpu,
            "mem": self.jetson.memory,
            "gpu": self.jetson.gpu,
            "pwr": self.jetson.power,
            "tmp": self.jetson.temperature,
            "upt": self.jetson.uptime,
            "disk": self.jetson.disk,
            "processes": self.jetson.processes
        }

        return self.data

class Jetson(object):
    def __init__(self, update_period=1):

        if float(update_period) < 0.5:
            raise BlockingIOError("Jetson Stats only works with 0.5s monitoring intervals and slower.")

        self.jtop_observer = JtopObservable(update_period=update_period)
        self.jtop_stats = {}
        self.interval = update_period

    def update(self):
        self.jtop_stats = self.jtop_observer.read_stats()

class JetsonExporter(object):

    def __init__(self, update_period):
        self.jetson = Jetson(update_period)
        self.name = "Jetson"

    def __cpu(self):
        cpu_gauge = GaugeMetricFamily(
            name="cpu",
            documentation="CPU Statistics from Jetson Stats (ARMv8 Processor rev 1 (v8l))",
            labels=["core", "statistic"],
            unit="Hz"
        )

        for core_number, core_data in enumerate(self.jetson.jtop_stats["cpu"]["cpu"]):
            cpu_gauge.add_metric([str(core_number), "freq"], value=core_data["freq"]["cur"])
            cpu_gauge.add_metric([str(core_number), "min_freq"], value=core_data["freq"]["min"])
            cpu_gauge.add_metric([str(core_number), "max_freq"], value=core_data["freq"]["max"])
            cpu_gauge.add_metric([str(core_number), "val"], value=core_data["idle"])
        return cpu_gauge

    def __gpu(self):
        gpu_gauge = GaugeMetricFamily(
            name="gpu_utilization_percentage",
            documentation="GPU Statistics from Jetson Stats",
            labels=["statistic", "nvidia_gpu"],
            unit="Hz"
        )

        gpu_names = self.jetson.jtop_stats["gpu"].keys()
        for gpu_name in gpu_names:
            gpu_gauge.add_metric([gpu_name, "freq"], value=self.jetson.jtop_stats["gpu"][gpu_name]["freq"]["cur"])
            gpu_gauge.add_metric([gpu_name, "min_freq"], value=self.jetson.jtop_stats["gpu"][gpu_name]["freq"]["min"])
            gpu_gauge.add_metric([gpu_name, "max_freq"], value=self.jetson.jtop_stats["gpu"][gpu_name]["freq"]["max"])
        return gpu_gauge

    def __gpuram(self):
        gpuram_gauge = GaugeMetricFamily(
            name="gpuram",
            documentation=f"Video Memory Statistics from Jetson Stats",
            labels=["statistic", "nvidia_gpu"],
            unit="kB"
        )

        gpu_names = self.jetson.jtop_stats["gpu"].keys()
        for gpu_name in gpu_names:
            gpuram_gauge.add_metric([gpu_name, "mem"], value=self.jetson.jtop_stats["mem"]["RAM"]["shared"])
        return gpuram_gauge

    def __ram(self):
        ram_gauge = GaugeMetricFamily(
            name="ram",
            documentation=f"Memory Statistics from Jetson Stats (unit: kB)",
            labels=["statistic"],
            unit="kB"
        )

        ram_gauge.add_metric(["total"], value=self.jetson.jtop_stats["mem"]["RAM"]["tot"])
        ram_gauge.add_metric(["used"], value=self.jetson.jtop_stats["mem"]["RAM"]["used"])
        ram_gauge.add_metric(["buffers"], value=self.jetson.jtop_stats["mem"]["RAM"]["buffers"])
        ram_gauge.add_metric(["cached"], value=self.jetson.jtop_stats["mem"]["RAM"]["cached"])
        ram_gauge.add_metric(["lfb"], value=self.jetson.jtop_stats["mem"]["RAM"]["lfb"])
        ram_gauge.add_metric(["free"], value=self.jetson.jtop_stats["mem"]["RAM"]["free"])
        return ram_gauge

    def __swap(self):
        swap_gauge = GaugeMetricFamily(
            name="swap",
            documentation=f"Swap Statistics from Jetson Stats",
            labels=["statistic"],
            unit="kB"
        )

        swap_gauge.add_metric(["total"], value=self.jetson.jtop_stats["mem"]["SWAP"]["tot"])
        swap_gauge.add_metric(["used"], value=self.jetson.jtop_stats["mem"]["SWAP"]["used"])
        swap_gauge.add_metric(["cached"], value=self.jetson.jtop_stats["mem"]["SWAP"]["cached"])
        return swap_gauge

    def __emc(self):
        emc_gauge = GaugeMetricFamily(
            name="emc",
            documentation=f"EMC Statistics from Jetson Stats",
            labels=["statistic"],
            unit="Hz"
        )

        emc_gauge.add_metric(["total"], value=self.jetson.jtop_stats["mem"]["EMC"]["cur"])
        emc_gauge.add_metric(["used"], value=self.jetson.jtop_stats["mem"]["EMC"]["max"])
        emc_gauge.add_metric(["cached"], value=self.jetson.jtop_stats["mem"]["EMC"]["min"])
        return emc_gauge

    def __temperature(self):
        temperature_gauge = GaugeMetricFamily(
            name="temperature",
            documentation=f"Temperature Statistics from Jetson Stats (unit: °C)",
            labels=["statistic", "machine_part", "system_critical"],
            unit="C"
        )

        for part, temp in self.jetson.jtop_stats['tmp'].items():
            temperature_gauge.add_metric([part], value=temp["temp"])
        return temperature_gauge

    def __integrated_power_machine_parts(self):
        power_gauge = GaugeMetricFamily(
            name="integrated_power",
            documentation="Power Statistics from internal power sensors (unit: mW/mV/mA)",
            labels=["statistic", "machine_part", "system_critical"]
        )

        for part, reading in self.jetson.jtop_stats["pwr"]["rail"].items():
            power_gauge.add_metric(["voltage"], value=reading["volt"])
            power_gauge.add_metric(["current"], value=reading["curr"])
            power_gauge.add_metric(["critical"], value=reading["warn"])
            power_gauge.add_metric(["power"], value=reading["power"])
            power_gauge.add_metric(["avg_power"], value=reading["avg"])
        return power_gauge

    def __integrated_power_total(self):
        power_gauge = GaugeMetricFamily(
            name="integrated_power",
            documentation="Power Statistics from internal power sensors (unit: mW)",
            labels=["statistic", "machine_part", "system_critical"],
            unit="mW"
        )

        power_gauge.add_metric(["power"], value=self.jetson.jtop_stats["pwr"]["tot"]["power"])
        power_gauge.add_metric(["avg_power"], value=self.jetson.jtop_stats["pwr"]["tot"]["avg"])
        return power_gauge

    def __disk(self):
        disk_gauge = GaugeMetricFamily(
            name="disk",
            documentation=f"Local Storage Statistics from Jetson Stats (unit: G)",
            labels=["mountpoint", "statistic"],
            unit="GB"
        )

        disk_gauge.add_metric(["total"], value=self.jetson.jtop_stats["disk"]["total"])
        disk_gauge.add_metric(["used"], value=self.jetson.jtop_stats["disk"]["used"])
        disk_gauge.add_metric(["available"], value=self.jetson.jtop_stats["disk"]["available"])
        return disk_gauge

    def __uptime(self):
        uptime_gauge = GaugeMetricFamily(
            name="uptime",
            documentation="Machine Uptime Statistics from Jetson Stats",
            labels=["statistic", "runtime"],
            unit="s"
        )
        
        uptime_gauge.add_metric(["alive"], value=self.jetson.jtop_stats["upt"].total_seconds())
        return uptime_gauge

    def __process(self):
        process_gauge = GaugeMetricFamily(
            name="process",
            documentation="Process Information from Jetson Stats",
            labels=["pid", "name", "priority", "state", "statistic"],
        )

        for process in self.jetson.jtop_stats["processes"]:
            pid, name, priority, state = str(process[0]), process[9], str(process[4]), process[5]
            # Add all metrics for the process as separate values under "MetricType"
            process_gauge.add_metric([pid, name, priority, state, "CPU"], value=process[6])
            process_gauge.add_metric([pid, name, priority, state, "RAM"], value=process[7])
            process_gauge.add_metric([pid, name, priority, state, "GPU_RAM"], value=process[8])
        return process_gauge


    def collect(self):
        self.jetson.update()
        yield self.__cpu()
        yield self.__gpu()
        yield self.__gpuram()
        yield self.__ram()
        yield self.__swap()
        yield self.__emc()
        yield self.__temperature()
        yield self.__integrated_power_machine_parts()
        yield self.__integrated_power_total()
        yield self.__disk()
        yield self.__uptime()
        yield self.__process()

def start_exporter(port=9100, update_period=1, logfile_cleanup_interval_hours=24):
    print(f"Node exporter running on port {port}. Querying speed: {update_period}s. "
                f"Cleanup frequency: {logfile_cleanup_interval_hours}")
    start_http_server(port)
    data_collector = JetsonExporter(update_period)

    sleep(update_period * 2)
    REGISTRY.register(data_collector)
    while True:
        schedule.run_pending()
        sleep(100)

def shutdown_handler(loop):
    logging.info("Shutting down  Jetson  Monitor...")
    mqtt_client.loop_stop()
    loop.stop()

async def main(args):
    mqtt_client.connect(args.broker_address, args.broker_port)
    mqtt_client.loop_start()
    
    exporter_task = asyncio.create_task(asyncio.to_thread(start_exporter, args.prometheus_port, args.interval))
    heartbeat_task = asyncio.create_task(check_node(args.node_name, args.interval, args.topic))
    await asyncio.gather(exporter_task, heartbeat_task)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Jetson monitor with Prometheus and MQTT.")
    parser.add_argument("--broker_address", type=str, required=True, help="MQTT broker address.")
    parser.add_argument("--broker_port", type=int, default=1883, help="MQTT broker port (default: 1883).")
    parser.add_argument("--prometheus_port", type=int, default=9100, help="Port for Prometheus metrics (default: 9100).")
    parser.add_argument("--topic", type=str, default='Node_heartbeat', help="MQTT topic to publish status (default: Node_heartbeat).")
    parser.add_argument("--node_name", type=str, required=True, help="The node name where this monitor is deployed.")
    parser.add_argument("--interval", type=int, default=1, help="Interval (in seconds) between Node checks (default: 1).")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info("Starting Jetson  Monitor...")

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda: shutdown_handler(loop))
    try:
        loop.run_until_complete(main(args))
    finally:
        loop.close()
