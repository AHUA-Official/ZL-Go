import cv2
import asyncio
import argparse
import logging
import signal
import json
import yaml
import time
from kubernetes import client, config
from prometheus_client import start_http_server, Gauge
import paho.mqtt.client as mqtt

logging.basicConfig(level=logging.WARNING)

# Load Kubernetes config
config.load_incluster_config()
core_v1 = client.CoreV1Api()

# Define metrics
rtsp_status_metric = Gauge('rtsp_stream_status', 'RTSP Stream Status', ['stream_url'])
rtsp_fps_metric = Gauge('rtsp_stream_fps', 'RTSP Stream Frame Rate', ['stream_url'])

# MQTT Client
mqtt_client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        logging.info("MQTT connected successfully.")
    else:
        logging.error(f"MQTT connection failed with code {rc}.")

mqtt_client.on_connect = on_connect

def publish_heartbeat(stream_url, topic):
    timestamp = time.time()
    message = {"stream_url":stream_url, "timestamp":timestamp}
    mqtt_client.publish(topic, json.dumps(message))
    logging.info(f"{message}: MQTT message published.")

async def check_rtsp(rtsp_url, time_interval, topic):
    while True:
        cap = cv2.VideoCapture(rtsp_url)
        try:
            if not cap.isOpened():
                rtsp_status_metric.labels(stream_url=rtsp_url).set(0)
                rtsp_fps_metric.labels(stream_url=rtsp_url).set(float('nan'))
                logging.warning(f"{rtsp_url}: RTSP source is not accessible.")
            else:
                fps = cap.get(cv2.CAP_PROP_FPS) if cap.get(cv2.CAP_PROP_FPS) > 0 else float('nan')
                rtsp_status_metric.labels(stream_url=rtsp_url).set(1)
                rtsp_fps_metric.labels(stream_url=rtsp_url).set(fps)
                publish_heartbeat(rtsp_url, topic)
                logging.info(f"{rtsp_url}: RTSP source is accessible. FPS: {fps}")
        except Exception as e:
            logging.error(f"Error checking RTSP stream {rtsp_url}: {e}")
        finally:
            cap.release()
        await asyncio.sleep(time_interval)

async def main(args):
    start_http_server(args.prometheus_port)
    mqtt_client.connect(args.broker_address, args.broker_port)
    mqtt_client.loop_start()

    try:
        config_map = core_v1.read_namespaced_config_map(args.config_map, args.namespace)
        perception_cfg = yaml.safe_load(config_map.data.get('config.yaml', '{}'))
        rtsp_urls = [cfg['url'] for cfg in perception_cfg.get('source-list', {}).values()]
    except Exception as e:
        logging.error(f"Failed to load ConfigMap or parse URLs: {e}")
        rtsp_urls = []

    tasks = [check_rtsp(url, args.interval, args.topic) for url in rtsp_urls]
    await asyncio.gather(*tasks)

def shutdown_handler(loop):
    logging.info("Shutting down RTSP Monitor...")
    mqtt_client.loop_stop()
    loop.stop()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RTSP monitor with Prometheus and MQTT.")
    parser.add_argument("--broker_address", type=str, required=True, help="MQTT broker address.")
    parser.add_argument("--broker_port", type=int, default=1883, help="MQTT broker port (default: 1883).")
    parser.add_argument("--topic", type=str, default='RTSP_heartbeat', help="MQTT topic to publish metrics (default: RTSP_heartbeat).")
    parser.add_argument("--prometheus_port", type=int, default=9100, help="Port for Prometheus metrics (default: 9100).")
    parser.add_argument("--namespace", type=str, default='default', help="Namespace that contains the ConfigMap (default: default).")
    parser.add_argument("--config_map", type=str, required=True, help="ConfigMap name containing RTSP URLs.")
    parser.add_argument("--interval", type=int, default=1, help="Interval (in seconds) between RTSP checks (default: 1).")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logging.info("Starting RTSP Monitor...")

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda: shutdown_handler(loop))
    try:
        loop.run_until_complete(main(args))
    finally:
        loop.close()
