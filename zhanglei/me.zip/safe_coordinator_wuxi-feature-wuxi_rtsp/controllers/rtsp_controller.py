import argparse
import logging
import json
import yaml
from jsonschema import validate, ValidationError  
from kubernetes import client, config
import paho.mqtt.client as mqtt

# Global vars
last_rtsp_status = {}

rtsp_schema = {
    "type": "object",
    "properties": {
        "rtsp_url": {"type": "string"},
        "timestamp": {"type": "string"}
    },
    "required": ["rtsp_url", "timestamp"]
}

node_schema = {
    "type": "object",
    "properties": {
        "node_name": {"type": "string"},
        "timestamp": {"type": "string"}
    },
    "required": ["node_name", "timestamp"]
}


# Load Kubernetes config
config.load_incluster_config()
core_v1 = client.CoreV1Api()



def setup_mqtt_client(broker_address, port):
    """Setup MQTT client."""
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            logging.info("Connected to MQTT Broker!")
        else:
            logging.error(f"Failed to connect, return code {rc}")

    mqtt_client = mqtt.Client()
    mqtt_client.on_connect = on_connect
    return mqtt_client

def update_config_map(config_map_name, update_function, url,namespace):
    """Update ConfigMap using the given function."""
    v2x_config = core_v1.read_namespaced_config_map(config_map_name, namespace)
    modified_data = update_function(v2x_config.data, url)
    v2x_config.data = modified_data
    core_v1.patch_namespaced_config_map(config_map_name, namespace, v2x_config)
    logging.info(f"ConfigMap '{config_map_name}' updated.")

def restart_pods(pod_prefix, namespace):
    """Restart pods with a specific prefix."""
    pods = core_v1.list_namespaced_pod(namespace=namespace)
    matching_pods = [pod.metadata.name for pod in pods.items if pod.metadata.name.startswith(pod_prefix)]
    for pod_name in matching_pods:
        core_v1.delete_namespaced_pod(pod_name, namespace)
        logging.info(f"Pod '{pod_name}' deleted for restart.")

def handle_rtsp_status_change(rtsp_url, new_status, config_map_name, pod_prefix,namespace):
    """Handle RTSP status change."""
    if last_rtsp_status.get(rtsp_url) == 1 and new_status == 0:
        logging.info(f"{rtsp_url} changed from UP to DOWN.")
        update_config_map(config_map_name, remove_broken_camera, rtsp_url,namespace)
        restart_pods(pod_prefix, namespace)
    elif last_rtsp_status.get(rtsp_url) == 0 and new_status == 1:
        logging.info(f"{rtsp_url} changed from DOWN to UP.")
        update_config_map(config_map_name, add_repaired_camera, rtsp_url,namespace)
        restart_pods(pod_prefix, namespace)
    last_rtsp_status[rtsp_url] = new_status


def subscribe_mqtt(client, topic, config_map_name, pod_prefix,namespace):
    """Subscribe to the MQTT topic."""
    def on_message(client, userdata, msg):
        
       
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            if "rtsp_url" in payload:
                validate(instance=payload, schema=rtsp_schema)
                rtsp_url = payload.get("rtsp_url")
                status = 1 
                timestamp=payload.get("timestamp")
                handle_rtsp_status_change(rtsp_url, status, config_map_name, pod_prefix,namespace)
                logging.info("GET RTSP Heartbeat!")
                if status ==1:
                    logging.info(f"Received message  {timestamp}: {rtsp_url} Good!! ")
                else:
                    logging.info(f"Received message  {timestamp}: {rtsp_url} BAd!!  ")

            elif "node_name" in payload:
                validate(instance=payload, schema=node_schema)
                node_name = payload.get("node_name")
                status = 1 if payload.get("status") == "alive" else 0
                handle_node_status_change(node_name, status, config_map_name, pod_prefix,namespace)
                logging.info("GET Jetson Heartbeat!")
                if status ==1:
                    logging.info(f"Received message  {timestamp}: {node_name} Good!! ")
                else:
                    logging.info(f"Received message  {timestamp}: {node_name} BAd!!  ")
                
            else:
                raise ValueError("Unknown message type.")
        
        except Exception as e:
            logging.error(f"Error processing MQTT message: {e}")

    client.subscribe(topic)
    client.on_message = on_message

def load_perception_init_cfg(config_map_name,namespace):
    """Load initial RTSP statuses from ConfigMap."""
    global last_rtsp_status
    try:
        config_map = core_v1.read_namespaced_config_map(args.config_map, namespace)
        perception_cfg = yaml.safe_load(config_map.data.get('config.yaml', '{}'))
        source_list = perception_cfg.get('source-list', {})
        for camera, camera_cfg in source_list.items():
            url = camera_cfg.get('url')
            if url:
                last_rtsp_status[url] = 1  # Assume UP initially
        logging.info(f"Initial RTSP statuses loaded from ConfigMap '{config_map_name}'.")
    except Exception as e:
        logging.error(f"Failed to load ConfigMap or parse URLs: {e}")

def run_mqtt(broker_address, port, topic, config_map_name, pod_prefix,namespace):
    """Run the MQTT subscriber."""
    client = setup_mqtt_client(broker_address, port)
    client.connect(broker_address, port)
    subscribe_mqtt(client, topic, config_map_name, pod_prefix,namespace)
    client.loop_forever()


def remove_broken_camera(config_data, url):
    # Parse the YAML content
    yaml_content = yaml.safe_load(config_data['config.yaml'])
    # if there is no "broken-source-list", create one
    if 'broken-source-list' not in yaml_content:
        yaml_content['broken-source-list'] = {}

    # Iterate over the cameras in the source-list, if find one's url that matches the input url, 
    # delete the term, move it to a new key: broken-source-list
    for camera, camera_cfg in list(yaml_content['source-list'].items()):
        # if camera_cfg has the key called 'url' and if they match each other
        if camera_cfg.get('url') == url:
            yaml_content['broken-source-list'][camera] = camera_cfg
            del yaml_content['source-list'][camera]
            break 
    
    # Convert the modified YAML content back to a string
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content
    return config_data

def add_repaired_camera(config_data, url):
    # Parse the YAML content
    yaml_content = yaml.safe_load(config_data['config.yaml'])
    # if there is no "broken-source-list", create one
    if 'broken-source-list' not in yaml_content:
        yaml_content['broken-source-list'] = {}

    # Iterate over the cameras in the broken-source-list, if find one url that matches the input url,
    # remove the term, move it to a new key: source-list
    for camera, camera_cfg in list(yaml_content['broken-source-list'].items()):
        if camera_cfg.get('url') == url:
            yaml_content['source-list'][camera] = camera_cfg
            del yaml_content['broken-source-list'][camera]
            break
    
    # Convert the modified YAML content back to a string
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content
    return config_data


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="RTSP controller based on MQTT monitoring.")
    parser.add_argument("--broker_address", type=str, required=True, help="MQTT broker address.")
    parser.add_argument("--broker_port", type=int, default=1883, help="MQTT broker port (default: 1883).")
    parser.add_argument("--topic", type=str, default='RTSP_status', help="MQTT topic to subscribe to (default: RTSP_status).")
    parser.add_argument("--config_map", type=str, required=True, help="ConfigMap name containing RTSP URLs.")
    parser.add_argument("--pod_prefix", type=str, default="perception", help="Pod prefix for restarts (default: 'perception').")
    parser.add_argument("--namespace", type=str, default="orin", help="Namespace for ConfigMap and pods.")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    logging.info("Starting RTSP Controllerr...")

    load_perception_init_cfg(args.config_map,args.namespace)
    run_mqtt(args.broker_address, args.broker_port, args.topic, args.config_map, args.pod_prefix,args.namespace)
