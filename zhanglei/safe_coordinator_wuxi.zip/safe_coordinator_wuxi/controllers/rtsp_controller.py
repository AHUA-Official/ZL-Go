import argparse
import json
import logging
import asyncio
import time
import signal
from jsonschema import validate, ValidationError
import inspect
import traceback
import threading
import paho.mqtt.client as mqtt
import yaml
from kubernetes import client, config
from prometheus_client import start_http_server, Gauge
from prometheus_client.core import GaugeMetricFamily, CounterMetricFamily, REGISTRY
from prometheus_client import Counter
from rtsp_config import RTSPConfig, log2star, node_schema, rtsp_schema, get_configmap_now, load_init_configmap, restart_pods, update_metrics
import queue
from rtsp_handler import remove_broken_camera, add_repaired_camera, find_available_node, move_camera_to_node, add_repaired_node

# Init RTSP_CONFIG
config_instance = RTSPConfig()
# Load Kubernetes config
config.load_incluster_config()
core_v1 = client.CoreV1Api()
# MQTT Client
mqtt_client = mqtt.Client()
# Prometheus metrics
rtsp_to_node_metric = Gauge('rtsp_node', 'RTSP to Node Mapping', ['rtsp_url', 'node_name'])
# 事件队列和锁
event_queue = queue.Queue()
processing_lock = threading.Lock()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        logging.info("MQTT connected successfully.")
    else:
        logging.error(f"MQTT connection failed with code {rc}.")

mqtt_client.on_connect = on_connect

def on_message(client, userdata, msg):
    logging.info(f"Received MQTT message on topic {msg.topic}")
    try:
        payload = json.loads(msg.payload.decode("utf-8"))
        if "RTSP_heartbeat" in msg.topic:
            validate(instance=payload, schema=rtsp_schema)
            rtsp_url = payload.get("stream_url")
            timestamp = payload.get("timestamp")
            status = 1
            logging.info(f"GET RTSP Heartbeat! {timestamp}: {rtsp_url}")
            config_instance.update_heartbeat(rtsp_url, timestamp)
            handle_camera_change(
                rtsp_url, status, args.config_map, args.pod_prefix, args.namespace)
        elif "Node_heartbeat" in msg.topic:
            validate(instance=payload, schema=node_schema)
            node_name = payload.get("node_name")
            timestamp = payload.get("timestamp")
            status = 1
            logging.info(f"GET Jetson Heartbeat! {timestamp}: {node_name}")
            config_instance.update_heartbeat(node_name, timestamp)
            handle_node_change(
                node_name, status, args.config_map, args.pod_prefix, args.namespace)
        else:
            raise ValueError("Unknown message type.")

    except Exception as e:
        logging.error(f"Error processing MQTT message: {e}")

mqtt_client.on_message = on_message

def update_config_map(config_map_name, update_function, namespace, **kwargs):
    try:
        v2x_config = core_v1.read_namespaced_config_map(
            config_map_name, namespace)
        sig = inspect.signature(update_function)
        param_names = list(sig.parameters.keys())
        call_args = {'config_data': v2x_config.data}  # basic args
        # other args
        for param_name in param_names:
            if param_name != 'config_data' and param_name in kwargs:
                call_args[param_name] = kwargs[param_name]
        # update configmap
        modified_data = update_function(**call_args)
        logging.info(
            f"Using args  {call_args}  update{update_function},START!! ")
        v2x_config.data = modified_data
        core_v1.patch_namespaced_config_map(
            config_map_name, namespace, v2x_config)
        logging.info(f"ConfigMap '{config_map_name}'  updated successfully")
        logging.info(f"Updated current configuration list HAPPYHAPPYHAPPY")        
    except Exception as e:
        logging.error(
            f"Updating ConfigMap '{config_map_name}'  failed: {str(e)}")
        raise

def check_heartbeats(interval, timeout):
    """Periodically check device heartbeats, consider device offline if no heartbeat received beyond the interval"""
    while True:
        try:
            current_time = time.time()
            all_heartbeats = config_instance.get_all_heartbeats()

            for keyitem, last_time in list(all_heartbeats.items()):
                time_diff = current_time - float(last_time)
                if "rtsp://" in keyitem:
                    # Handle RTSP camera
                    if time_diff > timeout:
                        if config_instance.get_rtsp_status(keyitem) == 1:
                            logging.warning(
                                f"@@@detail RTSP_OFFLINE@@@ RTSP camera timeout: {keyitem}, "
                                f"no heartbeat for {time_diff:.1f} seconds")
                            handle_camera_change(
                                keyitem, 0, args.config_map, args.pod_prefix, args.namespace)
                else:
                    # Handle Jetson node
                    if time_diff > timeout:
                        if config_instance.get_node_status(keyitem) == 1:
                            logging.warning(
                                f"@@@detail NODE_OFFLINE@@@ Jetson node timeout: {keyitem}, "
                                f"no heartbeat for {time_diff:.1f} seconds")
                            handle_node_change(
                                keyitem, 0, args.config_map, args.pod_prefix, args.namespace)
                
            time.sleep(interval)
        except Exception as e:
            logging.error(f"Heartbeats checker error: {e}")
            logging.error(traceback.format_exc())

def process_events_worker():
    """workline,get events from quene"""
    while True:
        try:
            event_type, event_data = event_queue.get()
            with processing_lock:
                if event_type == "camera":
                    rtsp_url, status, config_map, pod_prefix, namespace = event_data
                    _handle_camera_change(rtsp_url, status, config_map, pod_prefix, namespace)
                elif event_type == "node":
                    node_name, status, config_map, pod_prefix, namespace = event_data
                    _handle_node_change(node_name, status, config_map, pod_prefix, namespace)
            event_queue.task_done()
        except Exception as e:
            logging.error(f"处理事件时出错: {e}")
            logging.error(traceback.format_exc())

event_processor = threading.Thread(target=process_events_worker, daemon=True)
event_processor.start()

def handle_camera_change(rtsp_url, new_status, config_map_name, pod_prefix, namespace):
    event_queue.put(("camera", (rtsp_url, new_status, config_map_name, pod_prefix, namespace)))

def handle_node_change(node_name, new_status, config_map_name, pod_prefix, namespace):

    event_queue.put(("node", (node_name, new_status, config_map_name, pod_prefix, namespace)))


def _handle_camera_change(rtsp_url, new_status, config_map_name, pod_prefix, namespace):
    node_name = config_instance.get_node_for_rtsp(rtsp_url)
    
    if not node_name:
        rtsp_mapping = config_instance.get_all_rtsp_mappings()
        logging.error(f"￥debug￥ 无法找到RTSP {rtsp_url}对应的节点。当前映射状态: {rtsp_mapping}")
        
        get_configmap_now(config_instance, core_v1, config_map_name, namespace, "source-list")
        
        node_name = config_instance.get_node_for_rtsp(rtsp_url)

    
    current_status = config_instance.get_rtsp_status(rtsp_url)
    logging.info(f"￥debug￥ 处理RTSP状态变更: {rtsp_url}, 旧状态: {current_status}, 新状态: {new_status}, 节点: {node_name}")
    
    if config_instance.get_rtsp_status(rtsp_url) == 1 and new_status == 0:
        logging.info(
            f"@@@detail RTSP_DOWN@@@ {rtsp_url} changed from UP to DOWN.")
        update_config_map(
            config_map_name=config_map_name,
            update_function=remove_broken_camera,
            namespace=namespace,
            url=rtsp_url
        )
        restart_pods(core_v1, node_name, pod_prefix, namespace)        
    elif config_instance.get_rtsp_status(rtsp_url) == 0 and new_status == 1:
        logging.info(
            f"@@@detail RTSP_UP@@@ {rtsp_url} changed from DOWN to UP.")
        update_config_map(
            config_map_name=config_map_name,
            update_function=add_repaired_camera,
            namespace=namespace,
            url=rtsp_url
        )
        restart_pods(core_v1, node_name, pod_prefix, namespace)
        
    config_instance.update_rtsp_status(rtsp_url, new_status)
    
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "source-list")
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "broken-source-list")
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "node_dead-source")
    update_metrics(config_instance,rtsp_to_node_metric)

    if new_status == 0:
        if rtsp_url in config_instance.rtsp_to_node_mapping:
            node = config_instance.get_node_for_rtsp(rtsp_url)
            logging.info(f"￥debug￥ RTSP离线，从映射中删除: {rtsp_url}")
            config_instance.remove_rtsp_mapping(rtsp_url)            
            if node:
                config_instance.remove_rtsp_from_node(node, rtsp_url)

def _handle_node_change(node_name, new_status, config_map_name, pod_prefix, namespace):
    current_status = config_instance.get_node_status(node_name)   
    if current_status is None:
        config_instance.update_node_status(node_name, new_status)
        logging.info(
            f"Node {node_name} initial status set to: {'online' if new_status == 1 else 'offline'}")
        return

    if current_status == 1 and new_status == 0:
        logging.warning(
            f"@@@detail NODE_DOWN@@@ Node {node_name} changed from online to offline.")
        target_node = find_available_node(config_instance, node_name)
        if target_node:
            logging.info(
                f"Selected node {target_node} as backup for failed node {node_name}")
            update_config_map(
                config_map_name=config_map_name,
                update_function=move_camera_to_node,
                namespace=namespace,
                offline_node=node_name,
                target_node=target_node,
                rtsp_config=config_instance
            )
            restart_pods(core_v1, target_node, pod_prefix, namespace)
            logging.info(
                "@@@detail CONFIG_STATUS_AFTER_NODE_DOWN@@@ Status after node went down")
        else:
            logging.error(
                f"Cannot find available node to take over cameras from node {node_name}")
    elif current_status == 0 and new_status == 1:
        logging.info(
            f"@@@detail NODE_UP@@@ Node {node_name} changed from offline to online.")
        # Update ConfigMap, restore node's original camera configuration
        update_config_map(
            config_map_name=config_map_name,
            update_function=add_repaired_node,
            namespace=namespace,
            recovered_node=node_name)
        # Restart Pods on recovered node
        restart_pods(core_v1, node_name, pod_prefix, namespace)
        logging.info(
            "@@@detail CONFIG_STATUS_AFTER_NODE_UP@@@ Status after node came back online")

    config_instance.update_node_status(node_name, new_status)

    # Refresh in-memory mappings from ConfigMap
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "source-list")
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "broken-source-list")
    get_configmap_now(config_instance, core_v1, config_map_name, namespace, "node_dead-source")
    update_metrics(config_instance, rtsp_to_node_metric)

def shutdown_handler(loop):
    logging.info("Shutting down RTSP controller...")
    mqtt_client.loop_stop()
    loop.stop()


async def main(args):
    start_http_server(args.prometheus_port)
    logging.info(f"Prometheus HTTP服务器已启动在端口 {args.prometheus_port}")
    
    mqtt_client.connect(args.broker_address, args.broker_port)
    topics = [(args.node_topic, 0), (args.rtsp_topic, 0)]
    mqtt_client.subscribe(topics)
    mqtt_client.loop_start()
    logging.info(f"已订阅MQTT主题: {topics}")

    load_init_configmap(config_instance, core_v1, args.config_map, args.namespace)
    logging.info("启动心跳检测线程...")

    update_metrics(config_instance, rtsp_to_node_metric)

    heartbeat_task = asyncio.create_task(
        asyncio.to_thread(check_heartbeats, args.interval, args.timeout))
    await asyncio.gather(heartbeat_task)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="RTSP controller based on MQTT monitoring.")
    parser.add_argument("--broker_address", type=str,
                        required=True, help="MQTT broker address.")
    parser.add_argument("--broker_port", type=int, default=1883,
                        help="MQTT broker port (default: 1883).")
    parser.add_argument("--node_topic", type=str, default='Node_heartbeat',
                        help="MQTT topic to subscribe to for node (default: Node_heartbeat).")
    parser.add_argument("--rtsp_topic", type=str, default='RTSP_heartbeat',
                        help="MQTT topic to subscribe to for rtsp (default: RTSP_heartbeat).")
    parser.add_argument("--config_map", type=str, required=True,
                        help="ConfigMap name containing RTSP URLs.")
    parser.add_argument("--pod_prefix", type=str, default="perception",
                        help="Pod prefix for restarts (default: 'perception').")
    parser.add_argument("--namespace", type=str, default="orin",
                        help="Namespace for ConfigMap and pods.")
    parser.add_argument("--interval", type=int, default=1,
                        help="Interval (in seconds) between Node checks (default: 1).")
    parser.add_argument("--timeout", type=int, default=3,
                        help="Timeout multiplier for heartbeat checks (default: 3).")
    parser.add_argument("--prometheus_port", type=int, default=9100,
                        help="Port for Prometheus metrics (default: 9100).")  
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s - %(levelname)s - %(message)s")
    logging.warning("Starting RTSP Controller...")

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, lambda: shutdown_handler(loop))
    try:
        loop.run_until_complete(main(args))
    finally:
        loop.close()
