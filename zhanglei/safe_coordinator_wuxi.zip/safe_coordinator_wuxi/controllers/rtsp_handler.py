import logging
import yaml
from rtsp_config import log2star


def remove_broken_camera(config_data, url):
    logging.info(f"OP: Removing broken camera waiting")
    logging.info(f"Broken camera URL: {url}")
    # Parse the YAML content
    yaml_content = yaml.safe_load(config_data['config.yaml'])
    # if there is no "broken-source-list", create one
    if 'broken-source-list' not in yaml_content:
        yaml_content['broken-source-list'] = {}

    # Iterate over the cameras in the source-list, if find one's url that matches the input url,
    # delete the term, move it to a new key: broken-source-list
    for camera, camera_cfg in list(yaml_content['source-list'].items()):
        # if camera_cfg has the key called 'url' and if they match each other
        if camera_cfg.get('url') == url:
            yaml_content['broken-source-list'][camera] = camera_cfg
            del yaml_content['source-list'][camera]
            logging.info(
                f"@@@detail CAMERA_MOVED_TO_BROKEN@@@ Camera '{camera}' moved to broken list")
            break

    # Convert the modified YAML content back to a string
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content
    logging.info(f"OP: Removing broken camera finished")
    logging.info(f"{log2star}")
    return config_data

def add_repaired_camera(config_data, url):
    logging.info(f"OP: Adding repaired camera waiting")
    logging.info(f"Repaired camera URL: {url}")
    yaml_content = yaml.safe_load(config_data['config.yaml'])
    # if there is no "broken-source-list", create one
    if 'broken-source-list' not in yaml_content:
        yaml_content['broken-source-list'] = {}

    # Iterate over the cameras in the broken-source-list, if find one url that matches the input url,
    # remove the term, move it to a new key: source-list
    for camera, camera_cfg in list(yaml_content['broken-source-list'].items()):
        if camera_cfg.get('url') == url:
            yaml_content['source-list'][camera] = camera_cfg
            del yaml_content['broken-source-list'][camera]
            logging.info(
                f"@@@detail CAMERA_RESTORED@@@ Camera '{camera}' moved to active list")
            break

    # Convert the modified YAML content back to a string
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content

    logging.info(f"OP: Adding repaired camera finished")
    logging.info(f"{log2star}")
    return config_data

def find_available_node(rtsp_config, failed_node):
    """Node migration strategy"""
    logging.info(f"OP: Finding available node for: {failed_node}")
    
    # 获取节点状态的副本
    node_status_copy = {}
    with rtsp_config.lock:
        node_status_copy = dict(rtsp_config.last_node_status)
        
    for node, status in node_status_copy.items():
        # Skip the failed node itself and other offline nodes
        if node != failed_node and status == 1:
            logging.info(f"OP: Using node {node} ")
            return node
            
    logging.info(f"OP: Finding available node finished")
    logging.info(f"{log2star}")
    return None
def move_camera_to_node(config_data, offline_node, target_node, rtsp_config):
    logging.info(f"OP: Node failure, migrating RTSP waiting")
    
    # 获取节点迁移前的映射状态
    rtsp_mapping = rtsp_config.get_all_rtsp_mappings()
    node_mapping = rtsp_config.get_all_node_mappings()
    logging.info(f"￥debug￥ 节点迁移前映射状态: rtsp_to_node_mapping={rtsp_mapping}")

    
    yaml_content = yaml.safe_load(config_data['config.yaml'])

    if 'node_dead-source' not in yaml_content:
        yaml_content['node_dead-source'] = {}

    # 获取离线节点的RTSP URLs
    rtsp_urls = rtsp_config.get_rtsps_for_node(offline_node, []).copy()  # 创建副本避免迭代时修改
        
    if not rtsp_urls:
        logging.info(
            f"Node {offline_node} has no associated RTSP streams, no migration needed")
        return config_data

    logging.info(
        f"@@@detail NODE_STREAMS@@@ Node {offline_node} associated RTSP streams: {rtsp_urls}")

    moved_count = 0
    source_list = yaml_content['source-list']

    for camera, camera_cfg in list(source_list.items()):
        if camera_cfg.get('url') in rtsp_urls:

            yaml_content['node_dead-source'][f"{camera}_{offline_node}"] = dict(
                camera_cfg)

            camera_cfg['node_name'] = target_node
            moved_count += 1

            logging.info(
                f"@@@detail CAMERA_MIGRATED@@@ Camera '{camera}' moved from node '{offline_node}' to '{target_node}', original configuration backed up")

            # 更新映射关系
            url = camera_cfg.get('url')
            rtsp_config.update_mapping(url, target_node)
            rtsp_config.remove_rtsp_from_node(offline_node, url)
            rtsp_config.update_node_mapping(target_node, url)
                
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content

    # Print updated status
    logging.info(
        f"@@@detail MIGRATION_SUMMARY@@@ [Node {offline_node} offline] Migrated {moved_count} RTSP sources to node {target_node}")

    logging.info(f"OP: Node failure, migrating RTSP finished")
    logging.info(f"{log2star}")

    # 获取节点迁移后的映射状态
    rtsp_mapping = rtsp_config.get_all_rtsp_mappings()
    node_mapping = rtsp_config.get_all_node_mappings()
    logging.info(f"￥debug￥ 节点迁移后映射状态: rtsp_to_node_mapping={rtsp_mapping}")


    return config_data

def add_repaired_node(config_data, recovered_node):
    """When a node comes back online, restore its original camera configuration"""
    logging.info(f"OP: Node recovery, restoring RTSP waiting")
    logging.info(
        f"OP: Node back online, preparing to restore configuration: {recovered_node}")
    yaml_content = yaml.safe_load(config_data['config.yaml'])

    if 'node_dead-source' not in yaml_content:
        logging.info(
            f"No node failure backup list found, unable to restore configuration for node {recovered_node}")
        return config_data

    restored_count = 0
    # Find configurations in the backup list that belong to the recovered node
    for backup_key, backup_cfg in list(yaml_content['node_dead-source'].items()):
        if backup_key.endswith(f"_{recovered_node}") and backup_cfg.get('node_name') == recovered_node:
            # Extract original camera name
            original_camera = backup_key.rsplit('_', 1)[0]

            # Update node assignment in source-list or add back to source-list
            yaml_content['source-list'][original_camera] = backup_cfg

            # Remove from backup list
            del yaml_content['node_dead-source'][backup_key]

            restored_count += 1
            logging.info(
                f"@@@detail CAMERA_RESTORED@@@ Restored camera '{original_camera}' to node '{recovered_node}'")

    # Convert modified YAML content back to string
    modified_content = yaml.dump(yaml_content, default_flow_style=False)
    config_data['config.yaml'] = modified_content

    logging.info(
        f"@@@detail RESTORATION_SUMMARY@@@ [Node {recovered_node} back online] Restored {restored_count} RTSP sources")

    

    logging.info(f"OP: Node recovery, restoring RTSP finished")
    logging.info(f"{log2star}")
    return config_data