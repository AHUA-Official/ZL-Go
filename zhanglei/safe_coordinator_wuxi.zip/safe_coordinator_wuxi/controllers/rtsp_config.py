import threading
import logging
import yaml
import traceback
import time
# Global vars
log2star = "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"

rtsp_schema = {
    "type": "object",
    "properties": {
        "stream_url": {"type": "string"},
        "timestamp": {"type": "number"}
    },
    "required": ["stream_url", "timestamp"]
}

node_schema = {
    "type": "object",
    "properties": {
        "node_name": {"type": "string"},
        "timestamp": {"type": "number"}
    },
    "required": ["node_name", "timestamp"]
}
# RTSP配置类
class RTSPConfig:
    def __init__(self):
        self.lock = threading.Lock()
        self.last_rtsp_status = {}
        self.last_node_status = {}
        self.last_heartbeat = {}
        self.rtsp_to_node_mapping = {}
        self.node_to_rtsp_mapping = {}
    
    def get_rtsp_status(self, url, default=None):
        with self.lock:
            return self.last_rtsp_status.get(url, default)
    
    def get_node_status(self, node_name, default=None):
        with self.lock:
            return self.last_node_status.get(node_name, default)
    
    def get_heartbeat(self, key, default=None):
        with self.lock:
            return self.last_heartbeat.get(key, default)
    
    def get_node_for_rtsp(self, rtsp_url, default=None):
        with self.lock:
            return self.rtsp_to_node_mapping.get(rtsp_url, default)
    
    def get_rtsps_for_node(self, node_name, default=None):
        with self.lock:
            return self.node_to_rtsp_mapping.get(node_name, default)
    
    def update_rtsp_status(self, url, status):
        with self.lock:
            self.last_rtsp_status[url] = status

    def update_node_status(self, node_name, status):
        with self.lock:
            self.last_node_status[node_name] = status

    def update_heartbeat(self, key, timestamp):
        with self.lock:
            self.last_heartbeat[key] = timestamp

    def update_mapping(self, rtsp_url, node_name):
        with self.lock:
            self.rtsp_to_node_mapping[rtsp_url] = node_name

    def update_node_mapping(self, node_name, rtsp_url):
        with self.lock:
            if node_name not in self.node_to_rtsp_mapping:
                self.node_to_rtsp_mapping[node_name] = []
            if rtsp_url not in self.node_to_rtsp_mapping[node_name]:
                self.node_to_rtsp_mapping[node_name].append(rtsp_url)
    
    def remove_rtsp_from_node(self, node_name, rtsp_url):
        with self.lock:
            if node_name in self.node_to_rtsp_mapping and rtsp_url in self.node_to_rtsp_mapping[node_name]:
                self.node_to_rtsp_mapping[node_name].remove(rtsp_url)
    
    def remove_rtsp_mapping(self, rtsp_url):
        with self.lock:
            if rtsp_url in self.rtsp_to_node_mapping:
                del self.rtsp_to_node_mapping[rtsp_url]
    
    def clear_mappings(self):
        with self.lock:
            self.rtsp_to_node_mapping.clear()
            self.node_to_rtsp_mapping.clear()
    
    def get_all_heartbeats(self):
        with self.lock:
            return dict(self.last_heartbeat)
    
    def get_all_rtsp_mappings(self):
        with self.lock:
            return dict(self.rtsp_to_node_mapping)
    
    def get_all_node_mappings(self):
        with self.lock:
            return dict(self.node_to_rtsp_mapping)
        
def load_init_configmap(rtsp_config, Core, config_map_name, namespace):
    """Load initial RTSP<->Node statuses from ConfigMap."""
    logging.info(f"{log2star}")
    logging.info(f"OP: initial Init ConfigMAP START!")

    try:
        config_map = Core.read_namespaced_config_map(
            config_map_name, namespace)
        perception_cfg = yaml.safe_load(
            config_map.data.get('config.yaml', '{}'))
        source_list = perception_cfg.get('source-list', {})

        for camera, camera_cfg in source_list.items():
            url = camera_cfg.get('url')
            node_name = camera_cfg.get('node_name')
            if url and node_name:
                # RTSP alive
                rtsp_config.update_rtsp_status(url, 1)

                # Node alive
                rtsp_config.update_node_status(node_name, 1)

                # RTSP -> Node mapping
                rtsp_config.update_mapping(url, node_name)

                # last_heartbeat
                rtsp_config.update_heartbeat(url, time.time())
                rtsp_config.update_heartbeat(node_name, time.time())
                
                # Node->RTSP mapping
                rtsp_config.update_node_mapping(node_name, url)

        # Heartbeat monitoring initialization
        with rtsp_config.lock:
            heartbeat_count = len(rtsp_config.last_heartbeat)
        logging.info(f"Heartbeat monitoring initialized: {heartbeat_count} devices")

        # Node camera allocation
        logging.info(f"Camera allocation by node:")
        node_mappings = rtsp_config.get_all_node_mappings()
        for node, rtsp_list in node_mappings.items():
            online_count = sum(
                1 for url in rtsp_list if rtsp_config.get_rtsp_status(url, 0) == 1)
            total_count = len(rtsp_list)
            logging.info(f"  - Node {node}: {online_count}/{total_count} cameras online")

        # Detailed mapping information
        if logging.getLogger().level <= logging.DEBUG:
            with rtsp_config.lock:
                logging.debug(f"RTSP status mapping: {rtsp_config.last_rtsp_status}")
                logging.debug(f"Node status mapping: {rtsp_config.last_node_status}")
                logging.debug(f"RTSP->Node mapping: {rtsp_config.rtsp_to_node_mapping}")
                logging.debug(f"Node->RTSP mapping: {rtsp_config.node_to_rtsp_mapping}")
                logging.debug(f"Heartbeat timestamp record: {rtsp_config.last_heartbeat}")

    except Exception as e:
        logging.error(f"Failed to load ConfigMap or parse URL: {e}")
        logging.error(traceback.format_exc())

    get_configmap_now(rtsp_config, Core, config_map_name, namespace, "source-list")
    get_configmap_now(rtsp_config, Core, config_map_name, namespace, "broken-source-list")
    get_configmap_now(rtsp_config, Core, config_map_name, namespace, "node_dead-source")
    logging.info(f"OP: Initial configuration loading completed")
    logging.info(f"{log2star}")


def get_configmap_now(rtsp_config, Core, config_map_name, namespace, mylogkey):
    logging.info(f"{log2star}")
    try:
        # 添加映射状态前快照
        if mylogkey == 'source-list':
            rtsp_mapping = rtsp_config.get_all_rtsp_mappings()
            node_mapping = rtsp_config.get_all_node_mappings()
            logging.info(f"￥debug￥ get_configmap_now 更新映射前状态: rtsp_to_node_mapping={rtsp_mapping}")
 
        
        config_map = Core.read_namespaced_config_map(
            config_map_name, namespace)
        perception_cfg = yaml.safe_load(
            config_map.data.get('config.yaml', '{}'))

        # Check if the key exists
        if mylogkey not in perception_cfg:
            logging.info(
                f"Key '{mylogkey}' does not exist in configuration, returning empty dictionary")
            return {}

        source_list = perception_cfg.get(mylogkey, {})

        if not source_list:
            logging.info(f"'{mylogkey}' is empty")
            return {}

        logging.info(f"Retrieved {mylogkey} list: {list(source_list.keys())}")

        # Create a simplified dictionary for logging
        simplified_list = {}
        for camera, camera_cfg in source_list.items():
            url = camera_cfg.get('url')
            node_name = camera_cfg.get('node_name')
            type_value = camera_cfg.get('type')
            simplified_list[camera] = {
                'url': url, 'node_name': node_name, 'type': type_value}

        logging.info(f"Configuration details ({mylogkey}): {simplified_list}")

        # Update in-memory mappings
        if mylogkey == 'source-list':
            rtsp_config.clear_mappings()
            for camera, camera_cfg in source_list.items():
                url = camera_cfg.get('url')
                node_name = camera_cfg.get('node_name')
                if url and node_name:
                    rtsp_config.update_mapping(url, node_name)
                    rtsp_config.update_node_mapping(node_name, url)

            logging.info("In-memory mappings updated from ConfigMap.")
            rtsp_mapping = rtsp_config.get_all_rtsp_mappings()
            node_mapping = rtsp_config.get_all_node_mappings()
            logging.warning(f"rtsp_to_node_mapping{rtsp_mapping}")
            logging.warning(f"node_to_rtsp_mapping{node_mapping}")
            
        # 添加映射状态后快照
        if mylogkey == 'source-list':
            rtsp_mapping = rtsp_config.get_all_rtsp_mappings()
            logging.info(f"￥debug￥  get_configmap_now 更新映射后状态: rtsp_to_node_mapping={rtsp_mapping}")

        
        logging.info(f"{log2star}")
        return source_list
    except Exception as e:
        logging.error(f"￥debug￥ 获取ConfigMap失败: {e}, 调用栈: {traceback.format_exc()}")
        return {}

def restart_pods(Core, node_name, pod_prefix, namespace):
    """Restart pods with a specific prefix."""
    field_selector = f"spec.nodeName={node_name}"
    pods = Core.list_namespaced_pod(
        namespace=namespace, field_selector=field_selector)
    matching_pods = [
        pod.metadata.name for pod in pods.items
        if pod_prefix in pod.metadata.name]
    logging.info(f"{log2star}")
    logging.info(f"OP: Restarting pod waiting")
    logging.info(f"OP: Pods to be deleted {list(matching_pods)}")
    for pod_name in matching_pods:
        logging.info(f"OP: Deleting Pod '{pod_name}' to trigger restart...")
        Core.delete_namespaced_pod(pod_name, namespace)
        logging.info(f"Pod '{pod_name}' deleted for restart.")
        logging.info(
            f"Pod '{pod_name}' successfully deleted, waiting for recreation")
    logging.info(f"OP: Restarting pod finished")
    logging.info(f"{log2star}")

def update_metrics(rtsp_config, metric):
    """Update Prometheus metrics for RTSP to Node mapping."""
    # 清除所有现有的指标
    for sample in metric.collect():
        for s in sample.samples:
            metric.labels(**s[1]).set(0)
            
    # 获取当前映射关系的副本
    local_mapping = rtsp_config.get_all_rtsp_mappings()
    mapping_count = len(local_mapping)
    
    # 设置指标值
    for rtsp_url, node_name in local_mapping.items():
        metric.labels(rtsp_url=rtsp_url, node_name=node_name).set(1)
    
    logging.info(f"Prometheus指标更新完成: {mapping_count}个RTSP链接映射")
