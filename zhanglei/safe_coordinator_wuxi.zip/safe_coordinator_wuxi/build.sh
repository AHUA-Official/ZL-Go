REGISTRY=10.191.78.189:5000

cd host_monitor
sudo docker build -f jetson_monitor.dockerfile --network host --build-arg http_proxy="$http_proxy" --build-arg https_proxy="$https_proxy" -t v2x/jetson_monitor:1.0 .
sudo docker tag v2x/jetson_monitor:1.0  $REGISTRY/v2x/jetson_monitor:1.0
sudo docker push $REGISTRY/v2x/jetson_monitor:1.0
cd ..

cd sensor_monitor
sudo docker build -f rtsp_monitor.dockerfile --network host --build-arg http_proxy="$http_proxy" --build-arg https_proxy="$https_proxy" -t v2x/rtsp_monitor:1.0 .
sudo docker tag v2x/rtsp_monitor:1.0  $REGISTRY/v2x/rtsp_monitor:1.0
sudo docker push $REGISTRY/v2x/rtsp_monitor:1.0
cd ..

cd controllers
sudo docker build -f rtsp_controller.dockerfile --network host --build-arg http_proxy="$http_proxy" --build-arg https_proxy="$https_proxy" -t v2x/rtsp_controller:1.0 .
sudo docker tag v2x/rtsp_controller:1.0  $REGISTRY/v2x/rtsp_controller:1.0
sudo docker push $REGISTRY/v2x/rtsp_controller:1.0
cd ..
