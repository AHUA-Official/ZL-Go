#!/bin/bash

namespace="common"
kubectl get namespace "$namespace" >/dev/null 2>&1 || kubectl create namespace "$namespace"

helm install common helmcharts/coordinator_common -n "$namespace"

file=application/helmcharts/lab_v2x/orin.yaml
filename=$(basename "$file")
namespace="${filename%.yaml}"
kubectl get namespace "$namespace" >/dev/null 2>&1 || kubectl create namespace "$namespace"

helm install v2x application/helmcharts/v2x -f "$file" -n "$namespace"
helm install road helmcharts/coordinator_road -n "$namespace"
