<!---

	Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
	This program and the accompanying materials are made available under
	the terms of the Bosch Internal Open Source License v4
	which accompanies this distribution, and is available at
	http://bios.intranet.bosch.com/bioslv4.txt

-->

# Safe Coordination for Wuxi <!-- omit in toc -->

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

This repository implements a safe coordinator stack for Wuxi use case to handle failures in the roadside cluster that providing V2X services.
Backgound, requirement, technology selection, and implementation guideline can be found on Docupedia of CR activity [ICT-174](https://inside-docupedia.bosch.com/confluence2/display/ICT174):

- [General introduction for Wuxi use case](https://inside-docupedia.bosch.com/confluence2/display/ICT174/Wuxi+Pilot+Zone+Infrastructure-based+V2X).
- [Safety coordinator design document](https://inside-docupedia.bosch.com/confluence2/display/ICT174/Safety+Coordinator+Design).
- [Safety coordinator implementation document](https://inside-docupedia.bosch.com/confluence2/display/ICT174/Safe+Coordinator+Implementation).

## Table of Contents <!-- omit in toc -->

- [Structure](#structure)
- [Getting Started](#getting-started)
- [About](#about)

## Structure

```bash
${REPO_DIR}
|-- application
	|-- helmcharts (from ETAS)
	|-- test_yaml
|-- controllers
    |-- rtsp_controller
|-- helmcharts
    |-- coordinator_common (shared for all roads)
	|-- coordinator_road (distinguish each road)
|-- host_monitor
    |-- jeston_monitor
|-- rtsp_emulator (for test)
|-- sensor_monitor
    |-- rtsp_monitor
|-- visualization
|-- README.md
|-- LICENSE.txt
|-- ...
```

## Getting Started

### Premise

- K3s cluster and Helm are setup to manage Jetsons, i.e., `helm` is available in CLI.
- Application images are accessible in your registry, i.e., the registry k3s shall use.
- [jetson-stats 4.2.9](https://github.com/rbonghi/jetson_stats) is installed on all Jetson, i.e., `jtop` is available in CLI.
- `MAXN` power mode is activated on all Jetson, i.e., `jtop` shows `NV Power: MAXN`.

> Note that k3s uses `containerd` as its default runtime. Please ensure that NVIDIA container runtime is enabled on host, e.g., following [Alternative Container Runtime Support](https://docs.k3s.io/advanced#alternative-container-runtime-support) guideline from k3s.

### Prepare Images

Change the ```registry``` address to yours in `build.sh` and run:

```bash
bash build.sh
```

This will build all images and push them into your ```registry``` (The one K3s shall use).

> Note that `--network host --build-arg http_proxy="$http_proxy" --build-arg https_proxy="$https_proxy"` is needed under a network proxy for building Docker images.

### Application Dependency

The control logic reacting to monitors has dependency on application resources.
The folder `application` contains the relevant resource installation helmcharts.
It is based on [ETAS_E2E_Wuxi_V2X](https://sourcecode.socialcoding.bosch.com/projects/ETAS_E2E_SDV_OS_01/repos/etas_e2e_wuxi_v2x).
Application has dependency on RTSP cameras, which can be emulated using ```RTSP_emulator```.

### Installation

> `sudo chmod 644 /etc/rancher/k3s/k3s.yaml` might be needed to grant privilege.

**Using `helm`:**

When using helm, the node label needs to be set as intersection name.

```bash
# Set node's intersection
kubectl label nodes <node_name> v2x.intersection.name=<intersection_name>
```

All-in-one script:

```bash
# Set the files path
bash helm_install.sh
```

It will creates namesapces by filename (intersection), install common backend for all intersections, install application components and coordinator components on each intersection.

Uninstall by:
```bash
# Set the files path
bash helm_uninstall.sh
```

### Visualization

After deployment, you can access Grafana Web UI on `<Any-Host-IP>:30030`. Then you may import the dashboard provided in folder `visualization` to visualize the system status.

> Default login of Grafana is `admin/admin`.

## About

### Contributors

[Yifan Du](mailto:yifan.du@cn.bosch.com)

[Nan Li](mailto:nan.li3@cn.bosch.com)

### 3rd Party Licenses

| Package                | Version | License    | URL                                         |
| ---------------------- | ------- | ---------- | ------------------------------------------- |
| jetson-stats           | 4.2.9   | MIT        | https://github.com/rbonghi/jetson_stats     |
| schedule               | 0.6.0   | MIT        | https://github.com/dbader/schedule          |
| prometheus-client      | 0.7.1   | Apache-2.0 | https://github.com/prometheus/client_python |
| paho-mqtt              | 1.6.1   | EPL-2.0    | https://www.eclipse.org/paho/               |
| kubernetes             | 31.0.0  | Apache-2.0 | https://github.com/kubernetes-client/python |
| opencv-python-headless | Latest  | Apache-2.0 | https://github.com/opencv/opencv-python     |

### License

[![License: BIOSL v4](http://bios.intranet.bosch.com/bioslv4-badge.svg)](#license)

> Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
> This program and the accompanying materials are made available under
> the terms of the Bosch Internal Open Source License v4
> which accompanies this distribution, and is available at
> http://bios.intranet.bosch.com/bioslv4.txt

<!---

	Copyright (c) 2009, 2018 Robert Bosch GmbH and its subsidiaries.
	This program and the accompanying materials are made available under
	the terms of the Bosch Internal Open Source License v4
	which accompanies this distribution, and is available at
	http://bios.intranet.bosch.com/bioslv4.txt

-->
