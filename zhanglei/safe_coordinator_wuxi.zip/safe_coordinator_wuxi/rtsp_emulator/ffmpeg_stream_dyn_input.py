import socket

def send_command(command):
    host = 'localhost'
    port = 12345
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect((host, port))
        client_socket.sendall(command.encode())
        response = client_socket.recv(1024).decode()
        print(f"Action: {response}")

def manage_streams(stream_states):
    # Create commands based on the stream_states input
    stream_states_list = stream_states.split(',')
    commands = []
    
    # We assume the naming convention of streams as 'stream1', 'stream2', etc.
    for idx, state in enumerate(stream_states_list):    
        command = ""
        if state == '1':
            command = f"start stream{idx + 1}"
        elif state == '0':
            command = f"stop stream{idx + 1}"
        else:
            print(f"Invalid state '{state}' for stream {idx + 1}.")
            continue
        commands.append(command)

    return commands

def main():
    while True:                                  
        stream_states = input("Enter desired stream states (e.g., 0,0,1) or 'exit' to quit: ").strip()
        if stream_states.lower() == 'exit':
            break

        commands = manage_streams(stream_states)
        for command in commands:
            if command:  # Check if command is not empty
                send_command(command)

if __name__ == "__main__":
    main()
